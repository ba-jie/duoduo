package com.example.jiazhuangapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class NextActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
        // ---------------------------------------------------  
        // 自定义Activity标题栏  
        CustomTitleBar.getTitleBar(this,"我的自定义标题栏");
        //CustomTitleBar.hideBackBtn();
        // ---------------------------------------------------  
        /*返回按钮*/
        Button titleBackBtn = (Button) this.findViewById(R.id.head_TitleBackBtn);
        titleBackBtn.setOnClickListener(new OnClickListener() {  
        	public void onClick(View v) {
        		NextActivity.this.finish();
        	}  
        });  
        setContentView(R.layout.activity_next);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.next, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
}
